﻿#include <iostream>
#include <string>
#include <thread>
#include "socket.h"
#include "Tool.h"
#include <atomic>
#include <limits>

using namespace std;
#define ACCOUNT_LEN  4

void print_help_1()
{
    cout << "\n";
    cout << "---get usage    : help    \n";
    cout << "---login        : login   \n";
    cout << "---register     : register\n";
    cout << "---clear screen : clear   \n";
}
void print_help_2()
{
    cout << "\n";
    cout << "---get usage    : help    \n";
    cout << "---logout       : logout  \n";
    cout << "---clear screen : clear   \n";
    cout << "-------------------------------------------------------------------------------\n";
    cout<<  "If you want to look up a friend's UID by his name, please input 'search' \n";
    cout << "-------------------------------------------------------------------------------\n";
    cout << "If you want to send in groups, just write your content directly.\n";
    cout << "-------------------------------------------------------------------------------\n";
    cout << "If you want to send individually, you need to add 'UID-' before your content\n";
    cout << "-------------------------------------------------------------------------------\n\n";
}
int register_in(ClientSocket& client, int& status, string& str_pass_UID)
{

    int new_account;
    while (1) 
    {
        cout << "please input an account number(must be four numbers!!)\n";
        cin >> new_account;
        cin.clear();
        #undef max // 这里要用max，之前头文件有他的宏定义了
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');       
        if (new_account > 10000 || new_account < 1000) {
            cout << "your account is illegal.Please try again! ! !\n";
            new_account = -1;
            continue;
        }

        string ret = "$-5-";
        string new_password;
        string test_password;
        string new_name="-";
        cout << "please input an name(cannot contian spaces and '-! ! ! ! !) \n";     
        cin >> new_name;
        while (!is_legal(new_name)) {
            cout << "cannot contian spaces and '-' ,please try again\n";
            cin >> new_name;
        }
       
        while (1) 
        {
            cout << "please input an password (cannot contian spaces and '-! ! ! ! !) \n";
            cin >> new_password;
            while (!is_legal(new_password)) {
                cout << "cannot contian spaces and '-' ,please try again\n";
                cin >> new_password;
            }
            cout << "please input an password again\n";
            cin >> test_password;
            if (new_password != test_password) {
                cout << "The passwords are different.Please enter again!\n";
            }
            else {
                int cnt = 1;for (int i = 0;i < ACCOUNT_LEN - 1;i++)cnt *= 10;
                for (int i = 0;i < ACCOUNT_LEN;i++) {
                    ret += (new_account / cnt) + 48;
                    new_account %= cnt;
                    cnt /= 10;
                }
                ret += '-';
                ret += new_name;
                ret += '-';
                ret += new_password;
                break;
            }
        }
        client.send(ret.c_str(), ret.size());

        char buf[1024] = { '0' };
        int bytes = client.recv(buf, sizeof(buf));
        buf[bytes] = '\0';
        if (bytes >= 3 && buf[0] == '$' && buf[1] == '-') 
        {
            if (buf[2] == '3') {
                status = 3;
                string temp(buf);
                str_pass_UID = temp.substr(4);
                cout << " You have successfully registered and logged in ! !\n";
                int UID = 0;
                for (int i = 0;i < str_pass_UID.size();i++) {
                    UID *= 10;
                    UID += str_pass_UID[i] - 48;
                }
                return UID;
            }
            else if (buf[2] == '6') {
                cout << "This account already exists ! !please try again \n";
                continue;
            }
            else {
                cout << "sorry register false!!  please try again \n";
                continue;
            }
            ////////
        }
    }
    str_pass_UID = "";
    status = 0;
    return -1;
}


// 接收服务端消息的线程函数
void recv_thread(void* param)
{
    ClientSocket* client = (ClientSocket*)param;
    char buffer[1024];
    while (true) {
        int bytes = client->recv(buffer, sizeof(buffer));
        if (bytes >= 3) {
            buffer[bytes] = '\0';
            string str_buffer(buffer);
            if (buffer[2] == 'f') {
                if (buffer[4] == '-')
                {
                    cout << "Search failed, this user is not available\n";
                }
                else {
                    string UID = str_buffer.substr(4);
                    cout << "Search successfully ! ! His (Their) UID is " << UID << "\n\n";
                }
                continue;
            }
            if (buffer[2] == 'i') {
                string new_information = str_buffer.substr(4);
                cout << new_information << "\n\n";
                continue;
            }
            if (buffer[2] == '8')
            {
                cout << "information send successfully !\n\n";
                continue;
            }
            if (buffer[2] == '9')
            {
                cout << "information send failed !\n\n";
                continue;
            }
            if (buffer[2] == 'o')
            {
                cout << "Log out successfully! !\n";
                break;
            }
        }
    }
}


int main()
{
   
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        cerr << "WSAStartup failed: " << WSAGetLastError() << endl;
        return 1;
    }
    //// 1. 创建 socket
    //Socket client;
    //// 2.连接服务端 // 相同IP和端口
    //client.connect("127.0.0.1", 8080);
    ClientSocket client("106.14.45.80", 24228);
    cout << "------------------------------------\n";
    cout << "------------------------------------\n";
    cout << "-------Welcome To Micro Chat !------\n";
    cout << "------------------------------------\n";
    cout << "------Thank You For Your Using !----\n";
    cout << "------------------------------------\n";
    cout << "------------------------------------\n\n";

    cout << "input 'help' and you will get usage !\n\n";
 //   std::thread receiveThread(receiveMessages, client);
    // 0:未登录 1:准备检查账号 2:准备检查密码 
    // 3:已登录 4：准备注册
    int status = 0;  
    char buffer[1024];// 记录接收的消息
    string user_input;
    int pass_UID = -1;
    string str_pass_UID;
    string user_name;
    while (1)
    {
        // 登录循环
        while (1)
        {
            cin >> user_input;
            if (user_input == "help") {
                print_help_1();
                continue;
            }
            if (status == 0 && user_input == "register")
            {
                string rebuf = "$-2";
                client.send(rebuf.c_str(), rebuf.size());

                int bytes = client.recv(buffer, sizeof(buffer));
                buffer[bytes] = '\0';
                if (bytes == 3 && buffer[0] == '$' && buffer[1] == '-' && buffer[2] == '2') {
                    status = 4;
                    pass_UID = register_in(client, status, str_pass_UID);
                }
                //str_pass_UID = (string)pass_UID;
                if (pass_UID == -1)
                {
                    cout << "sorry register false!! please try again\n";
                    continue;
                }
                else break;
            }
            if (status == 0 && user_input == "login")
            {
                bool is_login = true;
                string data = "$-1";             
                int xx=client.send(data.c_str(), data.size());

                int bytes = client.recv(buffer, sizeof(buffer));
                if (bytes != 3 || buffer[0] != '$' || buffer[1] != '-' || buffer[2] != '1') 
                {
                    cout << "server response failed!!\n";
                    cout << "please send'login'and try again \n";
                    continue;
                }

                cout << "please input your account\n";
                cin >> data;
                string resend = "$-3-";resend += data;
                client.send(resend.c_str(), resend.size());

                resend = "$-4-";
                cout << "please input your password\n";
                cin >> data;
                resend += data;
                client.send(resend.c_str(), resend.size());
                bytes = client.recv(buffer, sizeof(buffer));   

                if (bytes > 4 && buffer[0] == '$' && buffer[2] == '4')
                {
                    buffer[bytes] = '\0';
                    string temp_UID(buffer);
                    str_pass_UID = temp_UID.substr(4);
                    pass_UID = 0;
                    for (int i = 4;i < bytes;i++) {
                        pass_UID *= 10;
                        pass_UID += temp_UID[i] - 48;
                    }

                    bytes = client.recv(buffer, sizeof(buffer));
                    if (bytes > 4 && buffer[2] == '4') {
                        buffer[bytes] = '\0';
                        string temp_name(buffer);
                        user_name = temp_name.substr(4);
                        status = 3;      
                        cout << "here";
                        break;
                    }
                }
                status = 0;
                pass_UID = -1;
                str_pass_UID = "";
                user_name = "";
                if (buffer[4] == '1') {
                    cout << "This account has been logged in\n";
                    cout << "Please send 'login'and log in to another account \n";
                    continue;
                }
                cout << "Sorry,your account number or password is incorrect\n";
                cout << "please send 'login'and try again \n";
                continue;
            }
            if (user_input == "clear")
            {
                system("cls");
                continue;
            }
            cout << "Incorrect input format !!\n";
            cout << "input 'help' and you will get usage !\n";
        }
        
        // 接收消息线程
        std::thread user_thread(recv_thread, &client);


        system("cls");
        cout << "------------------------------------\n";
        cout << "------------------------------------\n";
        cout << "-------Welcome To Micro Chat !------\n";
        cout << "------------------------------------\n";
        cout << "--You have successfully logged in!--\n";
        cout << "------------------------------------\n";
        cout << "---you can chat with friends now!---\n";
        cout << "------------------------------------\n";
        cout << "------Thank You For Your Using !----\n";
        cout << "------------------------------------\n\n";

        cout << "-------------------------------------------------------------------------------\n";
        cout << "If you want to send in groups, just write your content directly.\n";
        cout << "-------------------------------------------------------------------------------\n";
        cout << "If you want to send individually, you need to add 'UID-' before your content\n";
        cout << "-------------------------------------------------------------------------------\n";
        cout << "input 'help' and you will get usage !\n";
        cout << "-------------------------------------------------------------------------------\n\n";
        
        cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        // 发消息循环
        while (1)
        {
            getline(cin, user_input);
            if (user_input == "logout")
            {
                string data = "$-7";
                client.send(data.c_str(), data.size());
                status = 0;
                pass_UID = -1;
                str_pass_UID = "";
                user_name = "";
                
                break;
            }
            if (user_input == "clear")
            {
                system("cls");
                continue;
            }
            if (user_input == "help")
            {
                print_help_2();
                continue;
            }
            if (user_input == "search")
            {
                string friend_name;
                cout << "please input his name :\n";
                cin >> friend_name;
                string send = "$-f-";
                send += friend_name;
                client.send(send.c_str(), send.size());

                cin.clear();
                std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
                continue;
            }

            string str_send = "$-6-";
            str_send += user_input;
            client.send(str_send.c_str(), str_send.size());
            
        }
        user_thread.detach();
    }
    //// 3. 向服务端发送数据
    //string data = "hello world !!!!!!!!!!";
    //client.send(data.c_str(), data.size());
    //// 4.接收服务端的数据
    //char buffer[1024] = { '0' };
    //client.recv(buffer, sizeof(buffer));
    //cout << "\nrecv: " << buf << "\n";
    // 
    //Sleep(700);
    //// 5.关闭 socket
    //client.close();

    WSACleanup();
    return 0;
}

