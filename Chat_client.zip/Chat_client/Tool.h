#pragma once
#ifndef TOOL_H
#define TOOL_H
#include<iostream>
#include <string>
#include <ctime>
using namespace std;

string& _int_to_string(int x)
{
	string ret;
	if (x < 10) {
		ret += x + 48;return ret;
	}
	int cnt = 1;
	int temp = x;
	while (temp > 0) { cnt *= 10;temp /= 10; }
	cnt /= 10;
	while (cnt > 0) {
		ret += (x / cnt) + 48;
		x %= cnt;cnt /= 10;
	}
	return ret;
}

int _string_to_int(string& aim, int left, int right)
{
	int ret = 0, temp = 48;
	if (left > right)return 0;
	for (int i = left;i <= right;i++) {
		temp = aim[i];
		if (temp < 48 || temp>57) {
			return ret;
		}
		ret *= 10;
		ret += aim[i] - 48;
	}
	return ret;
}
bool is_legal(string& x)
{
	for (int i = 0;i < x.size();i++) {
		if (x[i] == ' ' || x[i] == '-')return false;
	}
	return true;
}
string get_time()
{
	std::time_t currentTime = std::time(nullptr);
	std::tm timeInfo; // ���� tm �ṹ���������ָ��
	if (localtime_s(&timeInfo, &currentTime) != 0) { // ʹ�� localtime_s ��������
		return ""; // �����������ؿ��ַ���
	}
	char buffer[80];
	std::strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", &timeInfo); // ע�� &timeInfo
	return string(buffer);
}

#endif