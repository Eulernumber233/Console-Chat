#pragma once
#ifndef SOCKET_H
#define SOCKET_H
#define _WINSOCK_DEPRECATED_NO_WARNINGS 
#include <iostream>
#include<winsock2.h>
#include <cstring>
#pragma comment(lib, "ws2_32.lib") // 链接ws2_32.lib库
using namespace std;
namespace yazi
{
	namespace socket
	{
		class Socket
		{
		public:
			Socket();
			// 用返回的连接套接字构造socket
			Socket(int sockfd);
			virtual~Socket();

			bool bind(const string& ip, int port);
			bool listen(int backlog);
			bool connect(const string& ip, int port);// 客户端的连接
			int accept();
			int send(const char* buf, int len);
			int recv(char* buf, int len);
			void close();

			bool set_non_blocking();//  设置成非阻塞I/O
			bool set_send_buffer(int size); // 设置发送缓冲区的大小
			bool set_recv_buffer(int size); // 设置接收缓冲区的大小
			bool set_linger(bool active, int seconds);
			bool set_keepalive(); // 发送心跳包 确认对方是否还在
			bool set_reuseaddr();
		//private:
			string m_ip; // ip
			int m_port;  // 端口
			int m_sockfd;// 套接字

			char buffer[256];

		};
		class ServerSocket :public Socket
		{
		public:
			ServerSocket() = delete;
			//~ServerSocket() = delete;
			ServerSocket(const string& ip, int port);

		};
		class ClientSocket :public Socket
		{
		public:
			ClientSocket() = delete;
			//~ClientSocket() = delete;
			ClientSocket(const string& ip, int port);

		};
	}

}
#endif

