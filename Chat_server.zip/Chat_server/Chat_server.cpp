﻿#include <ws2tcpip.h>
#include <winsock2.h>
#include <windows.h>
#include <iostream>
#include <thread>
#include <vector>
#include <map>
#include <mutex>
#include <shared_mutex>
#include "socket.h"
#include "DataBase.h"
#pragma comment(lib, "ws2_32.lib")
using namespace yazi::socket;
using namespace std;
#define _WINSOCK_DEPRECATED_NO_WARNINGS
#define ACCOUNT_LEN  4

// 存储客户端套接字等信息
struct ClientInfo {
    SOCKET clientSocket;
    sockaddr_in clientAddr;
    HANDLE threadHandle; // 存储处理该客户端的线程句柄
};

std::vector<ClientInfo> clients;         // 存储所有已连接到服务端的客户端信息
std::map<int, ClientInfo*> UID_to_socket; // UID到已登录客户端的套接字的映射
std::shared_mutex Data_lock;
std::shared_mutex UID_to_socket_lock;
std::mutex clients_lock;
std::mutex Log_lock;


// 处理单个客户端通信的线程函数
unsigned __stdcall handleClient(void* param) 
{
    ClientInfo* info = (ClientInfo*)param;
    SOCKET clientSocket = info->clientSocket;
    sockaddr_in clientAddr = info->clientAddr;

    // 0:未登录 1:准备检查账号 2:准备检查密码 3:已登录
    // 4：准备注册
    int status = 0;   // 当前线程的状态
    char buffer[1024];// 记录接收的消息
    int UID_pass = -1;// 当前线程登录的账号的UID
    string str_UID_pass;
    string pass_word; // 临时记录的密码
    string log_information; // 写入日志的信息
    string str_socket = to_string(static_cast<unsigned int>(clientSocket));
    while (true) 
    {
       
        // 服务端接收：
            // 登录 $-1 
            // 注册 $-2
            // 账号 $-3-xxxx
            // 密码 $-4-xxx
            // 注册的用户名账号密码 $-5-account-name-pass
            // 群发消息 $-6-xxxxxx     
            // 发送消息 $-6-UID-xxxxxx
            // 退出登录 $-7
            // 查询朋友UID $-f-name

        // 服务端发送：
            // 输入错误 $-0
            // 准备登录 $-1
            // 准备注册 $-2
            // 注册成功 $-3-UID
            // 账号密码正确 $-4-UID
            // 账号密码正确 $-4-name
            // 账号密码错误 $-5
            // 账号重复     $-6
            // 注册格式错误 $-7
            // 确认退出登录 $-o
            // 消息放送成功 $-8
            // 消息发送失败 $-9
            // 查询朋友UID  $-f-name
            // 有新消息到来 $-i-information

        // 接收数据
        int bytesRead = ::recv(clientSocket, buffer, sizeof(buffer), 0);
        if (bytesRead > 1&&bytesRead<1024) 
        {
            buffer[bytesRead] = '\0';
            string str_buffer(buffer);  

            log_information += str_buffer;
            log_information +="  Send from : ";
            log_information += str_socket;
            Log_lock.lock();
            LogSystem::getInstance().add_information(log_information);
            Log_lock.unlock();
            log_information = "";

            cout << "|| " << clientSocket << " || send information: " << str_buffer << "\n";
            
            if (buffer[0] != '$' || buffer[1] != '-') {
                string rebuf = "$-0";

                log_information += rebuf;
                log_information += "  Send to : ";
                log_information += str_socket;
                Log_lock.lock();
                LogSystem::getInstance().add_information(log_information);
                Log_lock.unlock();
                log_information = "";

                ::send(clientSocket, rebuf.c_str(), rebuf.size(), 0);
                continue;
            }

            // 接收准备登录信号
            if (status == 0 && buffer[2] == '1') {
                status = 1;
                string rebuf = "$-1";

                log_information += rebuf;
                log_information += "  Send to : ";
                log_information += str_socket;
                Log_lock.lock();
                LogSystem::getInstance().add_information(log_information);
                Log_lock.unlock();
                log_information = "";

                ::send(clientSocket, rebuf.c_str(), rebuf.size(), 0);
                continue;
            }

            // 检查账号是否存在
            if (status == 1 && buffer[2] == '3') {

                status = 2;
                std::shared_lock<std::shared_mutex>lock(Data_lock);
                for (auto& account : DataBase::getInstance().data_vec)
                {               
                    UID_pass=account.is_account(str_buffer);
                    if (UID_pass != -1) {
                        break;
                    }
                }
                continue;
            }

            // 检查密码是否正确
            if (status == 2 && buffer[2] == '4') {
              
                // 账号密码正确 $-4
                // 账号密码错误 $-5
                string data(buffer);
                cout << "UID_pass :" << UID_pass << "\n";
                std::shared_lock<std::shared_mutex>lock(Data_lock);
                std::unique_lock<std::shared_mutex>UID_lock(UID_to_socket_lock);
                int cnt = UID_to_socket.count(UID_pass);// 检查该账号是否已经登录
                if (UID_pass != -1 && DataBase::getInstance().data_vec[UID_pass].is_password(data) && cnt == 0) {

                    status = 3;
                   
                    UID_to_socket.emplace(UID_pass, info);
                    // 登录成功返回UID和名字
                    string rebuf = "$-4-";
                    str_UID_pass = DataBase::getInstance().data_vec[UID_pass].str_UID;                   
                    rebuf += str_UID_pass;

                    log_information += rebuf;
                    log_information += "  Send to : ";
                    log_information += str_socket;
                    Log_lock.lock();
                    LogSystem::getInstance().add_information(log_information);
                    Log_lock.unlock();
                    log_information = "";

                    cout << "rebuf=" << rebuf << "\n";
                    ::send(clientSocket, rebuf.c_str(), rebuf.size(), 0);
                    
                    rebuf = "$-4-";
                    rebuf += DataBase::getInstance().data_vec[UID_pass].client_name;

                    log_information += rebuf;
                    log_information += "  Send to : ";
                    log_information += str_socket;
                    Log_lock.lock();
                    LogSystem::getInstance().add_information(log_information);
                    Log_lock.unlock();
                    log_information = "";
                  
                    cout << "rebuf=" << rebuf << "\n";
                    Sleep(70);
                    ::send(clientSocket, rebuf.c_str(), rebuf.size(), 0);
                }
                else {
                    
                    status = 0;
                    UID_pass = -1;
                    str_UID_pass = "";
                    string rebuf = "$-5-0";

                    if (cnt != 0) {
                        rebuf[4] = '1';
                        cout << "This account has been logged in\n";
                    }

                    log_information += rebuf;
                    log_information += "  Send to : ";
                    log_information += str_socket;
                    Log_lock.lock();
                    LogSystem::getInstance().add_information(log_information);
                    Log_lock.unlock();
                    log_information = "";

                    ::send(clientSocket, rebuf.c_str(), rebuf.size(), 0);
                }
                pass_word = "####";
                continue;
            }

            // 接收准备注册信号
            if (status == 0 && buffer[2] == '2') {
                status = 4;
                string rebuf = "$-2";

                log_information += rebuf;
                log_information += "  Send to : ";
                log_information += str_socket;
                Log_lock.lock();
                LogSystem::getInstance().add_information(log_information);
                Log_lock.unlock();
                log_information = "";

                ::send(clientSocket, rebuf.c_str(), rebuf.size(), 0);
                cout << "new_is_ready_to_sign_in !!!\n";
                continue;
            }

            // 添加注册的账号
            if (status == 4 && buffer[2] == '5') {
                // $-5-account-name-pass
                string rebuf;
                string new_name;
                string new_password;
                int new_account = 0;
                for (int i = 4;i < 4 + ACCOUNT_LEN;i++) {
                    new_account *= 10;
                    new_account += str_buffer[i] - 48;
                }
                int jud = 0;// 0:记录用户名 1:记录密码 2:输入格式不对 3:账号已存在
                for (int i = 5 + ACCOUNT_LEN;i < str_buffer.size();i++) {
                    if (jud == 1 && str_buffer[i] == '-') {
                        jud = 2;break;
                    }
                    else if (jud == 0 && str_buffer[i] == '-') {
                        jud = 1;continue;
                    }
                    else if (jud == 1) {
                        new_password += str_buffer[i];
                    }
                    else new_name += str_buffer[i];
                }
                std::unique_lock<std::shared_mutex>lock(Data_lock);
                for (int i = 0;i < DataBase::getInstance().data_vec.size();i++) {
                    if (new_account == DataBase::getInstance().data_vec[i].account) {
                        jud = 3;break;
                    }
                }
                if (jud == 1) {                   
                    status = 3;
                    UID_pass = DataBase::getInstance().data_vec.size();

                    if (UID_pass < 10)str_UID_pass += UID_pass + 48;
                    else {
                        int temp = UID_pass;
                        int cnt = 1;while (cnt <= temp) { cnt *= 10; }
                        cnt /= 10;
                        while (cnt > 0) {                          
                            str_UID_pass += (temp / cnt) + 48;
                            temp %= cnt;
                            cnt /= 10;
                        }
                    }     
                    DataBase::getInstance().add_user(UID_pass, str_UID_pass, new_name, new_account, new_password);
                    DataBase::getInstance().Account_to_UID[new_account] = UID_pass;
                    std::unique_lock<std::shared_mutex>UID_lock(UID_to_socket_lock);
                    UID_to_socket.emplace(UID_pass, info);

                    string log_and_cout = "UID:";log_and_cout += str_UID_pass;
                    log_and_cout += "new_name: ";log_and_cout += new_name;
                    log_and_cout += "new_password: ";log_and_cout += new_password;
                    log_and_cout += " sign in success !!";
                    Log_lock.lock();
                    LogSystem::getInstance().add_information(log_and_cout);
                    Log_lock.unlock();
                    cout << "UID: " << UID_pass << "new_password: " << new_password << "new_account: " << new_account << " sign in success !!\n";

                    rebuf = "$-3-";
                    rebuf += str_UID_pass;
                    ::send(clientSocket, rebuf.c_str(), rebuf.size(), 0);                   
                }
                else if (jud == 3) {
                    status = 4;
                    rebuf = "$-6";
                    ::send(clientSocket, rebuf.c_str(), rebuf.size(), 0);
                }
                else {
                    status = 4;
                    rebuf = "$-7";
                    ::send(clientSocket, rebuf.c_str(), rebuf.size(), 0);
                }
                log_information += rebuf;
                log_information += "  Send to : ";
                log_information += str_socket;
                Log_lock.lock();
                LogSystem::getInstance().add_information(log_information);
                Log_lock.unlock();
                log_information = "";
                continue;
            }

            // 转发消息
            if (status == 3 && buffer[2] == '6')
            {
                string data = str_buffer.substr(4);
                int temp_UID = 0;bool is_group = true;int UID_long = 0;
                std::shared_lock<std::shared_mutex>lock(Data_lock);
                int max = DataBase::getInstance().data_vec.size();
                for (int i = 0;i < data.size();i++) {
                    if (data[i] == '-') {
                        is_group = false;
                        if (i == 0 && temp_UID == 0)is_group = true;
                        break;
                    }
                    if (data[i] < 48 || data[i]>57) {
                        is_group = true;break;
                    }
                    UID_long++;
                    temp_UID *= 10;
                    temp_UID += data[i] - 48;
                    if (i >= max) {
                        is_group = true;break;
                    }
                }
                string name = DataBase::getInstance().data_vec[UID_pass].client_name;
                string forward = "$-i-";string resend = "$-8";
                // cout << "temp_UID = " << temp_UID << "max = " << max << "is_group = " << is_group << "\n";
                if (temp_UID < 0 || temp_UID >= max || is_group)
                {       
                    std::shared_lock<std::shared_mutex>UID_lock(UID_to_socket_lock);
                    forward += name;forward += " (group):";forward += data;
                    for (auto& otherClient : UID_to_socket) {
                        if (otherClient.second == info)continue;
                        //cout << "auto& otherClient : UID_to_socket" << (otherClient.second)->clientSocket << "\n";
                        ::send((otherClient.second)->clientSocket, forward.c_str(), forward.size(), 0);
                    }

                    log_information += forward;
                    log_information += "  Send from :";
                    log_information += str_socket;
                    Log_lock.lock();
                    LogSystem::getInstance().add_information(log_information);
                    Log_lock.unlock();
                    log_information = "";

                    cout << forward << "\n";
                }
                else
                {
                    data = data.substr(UID_long + 1);
                    forward += name;forward += " (individually)";forward += data;
                    std::shared_lock<std::shared_mutex>UID_lock(UID_to_socket_lock);
                    const auto it = UID_to_socket.find(temp_UID);
                    if (it != UID_to_socket.end())
                    {
                        ::send((it->second)->clientSocket, forward.c_str(), forward.size(), 0);
                        forward +=" (success) !";
                    }
                    else {
                        forward += "(failure) he's not logged or doesn't exist !";
                        resend = "$-9";
                    }
                }
                log_information += forward;
                log_information += " Send from :";
                log_information += str_socket;
                Log_lock.lock();
                LogSystem::getInstance().add_information(log_information);
                Log_lock.unlock();
                log_information = "";
                cout << forward << " \n";
                ::send(clientSocket, resend.c_str(), resend.size(), 0);
                continue;
            }

            // 查询朋友UID
            if (status == 3 && buffer[2] == 'f')
            {
                string data = str_buffer.substr(4);
                std::shared_lock<std::shared_mutex>lock(Data_lock);
                string friend_UID = DataBase::getInstance().search_friend_UID(data);
                string resend = "$-f-";
                resend += friend_UID;

                log_information += resend;
                log_information += "  Send to : ";
                log_information += str_socket;
                Log_lock.lock();
                LogSystem::getInstance().add_information(log_information);
                Log_lock.unlock();
                log_information = "";
                
                //cout << resend << "aaaaaaaaaaaaaadadadad\n";
                ::send(clientSocket, resend.c_str(), resend.size(), 0);
            }

            // 退出登录
            if (status == 3 && buffer[2] == '7')
            {
                string resend = "$-o";
                ::send(clientSocket, resend.c_str(), resend.size(), 0);
                std::unique_lock<std::shared_mutex>UID_lock(UID_to_socket_lock);
                auto it = UID_to_socket.find(UID_pass);
                if (it != UID_to_socket.end() && it->second == info) {
                    UID_to_socket.erase(it);
                }
                status = 0;
                UID_pass = -1;
                str_UID_pass = "";
                continue;
            }          

        }
        else {
            // 接收错误
            std::cout << "recv error: " << WSAGetLastError() << std::endl;
    
            if (UID_pass >= 0) // 已登录
            {
                std::unique_lock<std::shared_mutex>UID_lock(UID_to_socket_lock);
                auto it = UID_to_socket.find(UID_pass); // 找到该套接字对应的登录UID
                if (it != UID_to_socket.end() && it->second == info) {
                    UID_to_socket.erase(it);
                }
            }
    
            // 从客户端列表移除该客户端信息
            clients_lock.lock();
            for (auto it = clients.begin(); it != clients.end(); ++it) {
                if (it->clientSocket == clientSocket) // 找到此线程的套接字对应已连接到服务端的客户端
                {
                    clients.erase(it); // 删除该已连接到服务端的客户端套接字等信息
                    break;
                }
            }
            clients_lock.unlock();
            delete info; info = nullptr;
            closesocket(clientSocket);
            break;
        }
    }
    _endthreadex(0);
    return 0;
}

int main() {
    WSADATA wsaData;
    // 初始化Windows Sockets库
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        std::cout << "WSAStartup failed: " << WSAGetLastError() << std::endl;
        return 1;
    }

    //int listenSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    //if (listenSocket == INVALID_SOCKET) {
    //    std::cout << "Socket creation failed: " << WSAGetLastError() << std::endl;
    //    WSACleanup();
    //    return 1;
    //}
    //string ip = "127.0.0.1";
    //int port = 8080;
    //struct sockaddr_in serverAddr;
    //memset(&serverAddr, 0, sizeof(serverAddr));
    //serverAddr.sin_family = AF_INET;
    //serverAddr.sin_addr.s_addr = inet_addr(ip.c_str());
    //serverAddr.sin_port = htons(port);// 主机地址到网络地址的转换
    //if (::bind(listenSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR) {
    //    std::cout << "Bind failed: " << WSAGetLastError() << std::endl;
    //    closesocket(listenSocket);
    //    WSACleanup();
    //    return 1;
    //}
    //if (::listen(listenSocket, 5) == SOCKET_ERROR) {
    //    std::cout << "Listen failed: " << WSAGetLastError() << std::endl;
    //    closesocket(listenSocket);
    //    WSACleanup();
    //    return 1;
    //}
    // 64433
    ServerSocket listenSocket("127.0.0.1",19203);
    cout << "ServerSocket ready !!\n";
    cout << listenSocket.m_sockfd << "\n";

    fd_set masterSet;
    FD_ZERO(&masterSet);
    FD_SET(listenSocket.m_sockfd, &masterSet);    
    SOCKET maxfd = listenSocket.m_sockfd;
    cout << "fd_set ready!!\n";
    cout << "Database initialization succeeded\n\n";

    while (true) 
    {
        fd_set readSet = masterSet;

        int result = select( maxfd+1, &readSet, NULL, NULL, NULL);
        
        //if (result == SOCKET_ERROR)
        //{
        //    std::cout << "select error: " << WSAGetLastError() << std::endl;
        //    break;
        //}
        for (int i = listenSocket.m_sockfd; i <= maxfd; i++)
        {
            //cout << FD_ISSET(i, &readSet)<<"\n";
            if (FD_ISSET(i, &readSet))
            {                
                if (i == listenSocket.m_sockfd)
                {
                    cout << "find client\n";
                    string log_new_client = "find new client : ";
                    log_new_client += to_string(static_cast<unsigned int>(i));
                    Log_lock.lock();
                    LogSystem::getInstance().add_information(log_new_client);
                    Log_lock.unlock();

                    // 处理新连接
                    sockaddr_in clientAddr;
                    int clientAddrLen = sizeof(clientAddr);
                    SOCKET clientSocket = ::accept(listenSocket.m_sockfd, (sockaddr*)&clientAddr, &clientAddrLen);
                    if (clientSocket != INVALID_SOCKET)
                    {
                        FD_SET(clientSocket, &masterSet);
                        if (clientSocket > maxfd) {
                            maxfd = clientSocket; // 更新最大文件描述符
                        }
                        // 创建线程处理新连接
                        ClientInfo* info = new ClientInfo{ clientSocket, clientAddr, NULL };                       
                        HANDLE threadHandle = (HANDLE)_beginthreadex(NULL, 0, handleClient, info, 0, NULL);
                        info->threadHandle = threadHandle;
                        clients_lock.lock();
                        clients.push_back(*info);
                        clients_lock.unlock();
                        // 必须要为info申请内存，如果是局部变量，容易导致局部变量复用
                        //ClientInfo info = { clientSocket, clientAddr, NULL };                      
                        //HANDLE threadHandle = (HANDLE)_beginthreadex(NULL, 0, handleClient, &info, 0, NULL);
                        //info.threadHandle = threadHandle;
                        //clients.push_back(info);
                    }
                }
            }
        }       
    }

    // 清理资源
    for (auto& client : clients) {
        WaitForSingleObject(client.threadHandle, INFINITE);
        CloseHandle(client.threadHandle);
    }
    closesocket(listenSocket.m_sockfd);
    WSACleanup();
    return 0;
}