#include "socket.h"
using namespace yazi::socket;
Socket::Socket() : m_ip(""), m_port(0), m_sockfd()
{
    // 1. 创建 socket
    m_sockfd = ::socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (m_sockfd < 0)
    {
        cout << "create socket error=" << WSAGetLastError() << "  errormsg=" << strerror_s(buffer, sizeof(buffer), errno) << "\n";
        return;
    }
    else
    {
        cout << "create socket success!\n";
    }
}

yazi::socket::Socket::Socket(int sockfd) :m_ip(""), m_port(0), m_sockfd(sockfd) {
}

Socket::~Socket()
{
    close();
}

bool Socket::bind(const string& ip, int port)
{
    struct sockaddr_in sockaddr;
    memset(&sockaddr, 0, sizeof(sockaddr));
    sockaddr.sin_family = AF_INET;
    if (ip.empty()) // 如果空串 绑定本地任意网卡的IP地址
    {
        sockaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    }
    else
    {
        sockaddr.sin_addr.s_addr = inet_addr(ip.c_str());
    }
    sockaddr.sin_addr.s_addr = inet_addr(ip.c_str());
    sockaddr.sin_port = htons(port);// 主机地址到网络地址的转换

    // ::表示全局的函数 //bind 参数一为socket，二为创建的结构体 struct sockaddr_in // 返回-1为出错
    if (::bind(m_sockfd, (struct sockaddr*)&sockaddr, sizeof(sockaddr)) < 0)
    {
        return false;
    }
    else
    {
        cout << "create socket success!\n";
        cout << "ip=" << ip.c_str() << " port=" << port << "\n";
    }
    m_ip = ip;
    m_port = port;

    return true;
}

bool Socket::listen(int backlog)
{


    // 3. 监听 socket
    if (::listen(m_sockfd, backlog) < 0)
    {
        cout << "socket listen error=" << WSAGetLastError() << "  errormsg=" << strerror_s(buffer, sizeof(buffer), errno) << "\n";
        return false;
    }
    else
    {
        cout << "socket  listen success!\n";
    }
    return true;
}

bool Socket::connect(const string& ip, int port)
{


    // 连接服务端 // 相同IP和端口
    struct sockaddr_in sockaddr;
    memset(&sockaddr, 0, sizeof(sockaddr));
    sockaddr.sin_family = AF_INET;
    sockaddr.sin_addr.s_addr = inet_addr(ip.c_str());// 主机到网络的一个格式转换   
    sockaddr.sin_port = htons(port);// 端口
    if (::connect(m_sockfd, (struct sockaddr*)&sockaddr, sizeof(sockaddr)) < 0)
    {
        cout << "socket connect error =" << WSAGetLastError() << "  errormsg=" << strerror_s(buffer, sizeof(buffer), errno) << "\n";
        return false;
    }
    m_ip = ip;
    m_port = port;

    return true;
}

int Socket::accept()
{


    // 接收客户端连接 
    // 阻塞监听，等待客户端消息
    int connfd = ::accept(m_sockfd, nullptr, nullptr);
    if (connfd < 0)
    {
        cout << "create accept error=" << WSAGetLastError() << "  errormsg=" << strerror_s(buffer, sizeof(buffer), errno) << "\n";
        return -1;
    }
    else
    {
        cout << "socket accept success!\n";
    }
    return connfd;
}

int yazi::socket::Socket::send(const char* buf, int len)
{
    return ::send(m_sockfd, buf, len, 0);
}

int yazi::socket::Socket::recv(char* buf, int len)
{
    return ::recv(m_sockfd, buf, len, 0);
}

void yazi::socket::Socket::close()
{
    if (m_sockfd > 0)
    {
        // 关闭socket 服务端的监听套接字
        ::closesocket(m_sockfd);
        m_sockfd = 0;
    }
}

bool yazi::socket::Socket::set_non_blocking()
{
    /*
        ioctlsocket函数
        参数1 要操作的套接字
        参数2 规定操作的类型
        参数3 指向具体参数值的指针
        设置为 0 表示关闭非阻塞模式 。
        函数调用成功返回 0 ，
    */
    u_long argp = 1;
    // FIONBIO用于设置非阻塞模式 argp 设置为 1 表示开启非阻塞模式 
    int result = ioctlsocket(m_sockfd, FIONBIO, &argp);
    if (result == 0) {
        return true;
    }
    else {
        std::cerr << "set socket non-blocking error= " << WSAGetLastError() << "\n";
        /*

            std::cout 具有缓冲机制
            这意味着它会将输出数据先存储在一个缓冲区中，
            当遇到特定的条件时，才会将数据真正输出到目标设备。

            std::cerr 通常是无缓冲的，
            这意味着当使用 std::cerr 输出数据时，
            数据会立即被输出到目标设备
        */
        return false;
    }

}

bool yazi::socket::Socket::set_send_buffer(int size)
{
    int buff_size = size;
    if (setsockopt(m_sockfd, SOL_SOCKET, SO_SNDBUF, (const char*)(&buff_size), sizeof(buff_size)) < 0)
    {
        std::cerr << "set set_send_buffer error= " << WSAGetLastError() << "\n";
        return false;
    }
    return true;
}

bool yazi::socket::Socket::set_recv_buffer(int size)
{
    int buff_size = size;
    if (setsockopt(m_sockfd, SOL_SOCKET, SO_RCVBUF, (const char*)(&buff_size), sizeof(buff_size)) < 0)
    {
        std::cerr << "set set_recv_buffer error= " << WSAGetLastError() << "\n";
        return false;
    }
    return true;
}

bool yazi::socket::Socket::set_linger(bool active, int seconds)
{
    struct linger l;
    std::memset(&l, 0, sizeof(l));
    l.l_onoff = active == 1 ? 1 : 0;
    l.l_linger = seconds;
    if (setsockopt(m_sockfd, SOL_SOCKET, SO_LINGER, (const char*)&l, sizeof(l)) < 0)
    {
        std::cerr << "set set_linger error= " << WSAGetLastError() << "\n";
        return false;
    }

    return true;
}

bool yazi::socket::Socket::set_keepalive()
{
    const char flag = 1;
    if (setsockopt(m_sockfd, SOL_SOCKET, SO_KEEPALIVE, &flag, sizeof(flag)) < 0)
    {
        std::cerr << "set set_keepalive error= " << WSAGetLastError() << "\n";
        return false;
    }
    return true;
}

bool yazi::socket::Socket::set_reuseaddr()
{
    const char flag = 1;
    if (setsockopt(m_sockfd, SOL_SOCKET, SO_REUSEADDR, &flag, sizeof(flag)) < 0)
    {
        std::cerr << "set set_reuseaddr error= " << WSAGetLastError() << "\n";
        return false;
    }
    return true;
}

yazi::socket::ServerSocket::ServerSocket(const string& ip, int port)
{
   // set_non_blocking();
    set_recv_buffer(10 * 1024);// 10k
    set_linger(true, 0);
    set_keepalive();
    set_reuseaddr();

    bind(ip, port);
    listen(2048);

}

yazi::socket::ClientSocket::ClientSocket(const string& ip, int port)
{
    connect(ip, port);
}
