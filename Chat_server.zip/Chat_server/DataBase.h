#pragma once
#ifndef DATABASE_H
#define DATABASH_H

#include<string>
#include <vector>
#include <fstream>
#include <map>

#define ACCOUNT_LEN  4
using namespace std;
class User
{
public:
    int UID;
    int account;
    string str_UID;
    string password;
    string client_name;
    int is_account(string& acc)
    {
        int x = 0;
        for (int i = 4;i < 4 + ACCOUNT_LEN;i++) {
            x *= 10;
            x += acc[i] - 48;
        }
        if (x == account) {
            return UID;
        }
        else return -1;
    }//$-4-xxx
    bool is_password(string& key)
    {
        if (key.size() != password.size() + 4)return false;
        for (int i = 0;i < password.size();i++) {
            if (key[i + 4] != password[i])return false;
        }
        return true;
    }
    User(int new_UID, string& new_str_UID, string& new_client_name, int& new_account, string& new_password) {
        str_UID = new_str_UID; UID = new_UID;  account = new_account; password = new_password;client_name = new_client_name;
    }
};

class DataBase
{
private:
    DataBase();
    static DataBase instance;
    DataBase(const DataBase&) = delete;
    DataBase& operator = (const DataBase&) = delete;
public:
    static DataBase& getInstance() {
        return instance;
    }
    vector<User>data_vec;
    std::map<int, int>Account_to_UID;        // �˺ŵ�UID��ӳ�� 
    void add_user(int new_UID, string& new_str_UID, string& new_client_name, int& new_account, string& new_password);
    string search_friend_UID(string friend_name);
};


class LogSystem
{
private:
    LogSystem();
    static LogSystem instance;
    LogSystem(const LogSystem&) = delete;
    LogSystem& operator = (const LogSystem&) = delete;
public:
    static LogSystem& getInstance() {
        return instance;
    }
    void add_information(string& information);
};



#endif

