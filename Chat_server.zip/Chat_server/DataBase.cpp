#include "DataBase.h"
#include "Tool.h"

DataBase DataBase::instance;
LogSystem LogSystem::instance;

DataBase::DataBase()
{
    std::fstream ifp("User_Data_Base.txt", std::ios::in);
    if (!ifp) {
        std::cout << "Failed to open file User_Data_Base" << std::endl;
        return;
    }
    string line;
    int UID; string str_UID; string name; int account; string password;
    // UID name accouter password
    int i = 0, j = 0, k = 0;
    while (getline(ifp, line))
    {
        for (int x = 0;x < line.size();x++) 
        {
            if(line[x]==' '){
                if (i == 0)i = x;
                else if (j == 0)j = x;
                else { k = x;break; }
            }
        }
        UID = _string_to_int(line, 0, i - 1);
        str_UID = line.substr(0, i);
        name = line.substr(i + 1, j - i - 1);
        account = _string_to_int(line, j+1, k-1);
        password = line.substr(k + 1, line.size() - k - 1);

        cout << UID << " " << str_UID << " " << name << " " << account << " " << password << "\n";

        Account_to_UID.insert({ account, UID });
        data_vec.push_back({ UID, str_UID, name, account, password });
        i = 0, j = 0, k = 0;
    }
    ifp.close();
    cout << "Database initialization succeeded\n\n";
}

void DataBase::add_user(int new_UID, string& new_str_UID, string& new_client_name, int& new_account, string& new_password)
{
    Account_to_UID.insert({ new_account, new_UID });
    data_vec.push_back({ new_UID,  new_str_UID,  new_client_name,new_account, new_password });
    std::fstream ofp;
    ofp.open("User_Data_Base.txt", std::ios::app);
    if (!ofp) {
        std::cout << "Error: Failed to open database file for writing.\n" << std::endl;
        return ;
    }
    // UID name accouter password
    ofp << new_str_UID << " " << new_client_name << " " << new_account << " " << new_password << "\n";
    ofp.close();
    cout << "New user added successfully\n\n";
}

string DataBase::search_friend_UID(string friend_name)
{
    string data = "-";
    for (int i = 0;i < data_vec.size();i++) {
        if (friend_name == data_vec[i].client_name)
            data += " ## " + data_vec[i].str_UID;
    }
    if (data != "-")
        data = data.substr(2);
    data += " ##";
    return data;
}


LogSystem::LogSystem()
{
    string new_start = get_time();
    if (new_start == "") {
        cout << "Failed to get time !\n";
        return;
    }
    new_start += " : new start Log Base\n";

    std::fstream ifp("Log_Base.txt", std::ios::app);    
    if (!ifp) {
        std::cout << "Failed to open file User_Data_Base\n";
        return;
    }
    ifp << new_start;
    ifp.close();
    cout << "open Log Base successfully\n\n";
}

void LogSystem::add_information(string& information)
{
    string new_information = get_time();
    if (new_information == "") {
        cout << "Failed to get time !\n";
        return;
    }
    new_information += information + "\n";

    std::fstream ifp("Log_Base.txt", std::ios::app);
    if (!ifp) {
        std::cout << "Failed to open file User_Data_Base\n";
        return;
    }
    ifp << new_information;
    ifp.close();
    cout << "add to Log successfully\n\n";
}
